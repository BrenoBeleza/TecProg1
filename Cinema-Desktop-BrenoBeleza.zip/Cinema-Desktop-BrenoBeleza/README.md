# CINEMA APP
Project UML:
![Cinema](https://user-images.githubusercontent.com/32599120/211403645-eca6aa1a-16c2-42ac-88be-5683add2f636.png)
